import { ThrowStmt } from "@angular/compiler";

export class User {
    id:number;
    email:string;
    userName:string;
    password:string;

    constructor(){}

}
