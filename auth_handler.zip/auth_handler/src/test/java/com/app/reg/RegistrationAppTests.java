package com.app.reg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistrationAppTests {

	@Test
	void contextLoads() {
	}

}
