package com.app.reg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.reg.model.User;
import com.app.reg.repository.RegistrationRepository;

@Service
public class RegistrationService {

	@Autowired
	private RegistrationRepository repo;

	public User saveUser(User user) {
		return repo.save(user);
	}

	public User fetchUserByEmailId(String email) {
		return repo.findByEmail(email);
	}

	public User fetchUserByEmailIdAndPassword(String email, String password) {
		return repo.findByEmailAndPassword(email, password);
	}
}
